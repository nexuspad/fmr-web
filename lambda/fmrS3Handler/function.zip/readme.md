npm install --arch=x64 --platform=linux sharp

zip -r function.zip .
